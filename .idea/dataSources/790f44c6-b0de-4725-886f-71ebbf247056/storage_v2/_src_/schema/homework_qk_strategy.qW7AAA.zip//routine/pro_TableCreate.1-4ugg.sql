create
    definer = homework@`%` procedure pro_TableCreate()
BEGIN
DECLARE i INT;
DECLARE table_name VARCHAR(20);
SET i = 0;
 
WHILE i<13 DO
#为了使表名成为xxx00这样的格式加的条件判断

SET table_name = CONCAT('tblMessageSpamDetai',i);

 
SET @csql = CONCAT(
'CREATE TABLE ',table_name,'(
ID bigint(18) UNSIGNED NOT NULL auto_increment COMMENT"注释",
UserID int(10) comment"注释",
ModularID int(4) comment"注释",
BillTypeID int(4) comment"注释",
BillerID bigint(18) comment"注释",
LogTypeID smallint(2) default "0" comment"注释",
Log varchar(1000) comment"注释",
LogDate datetime comment"注释",
Deleted tinyint(1) DEFAULT "0" comment"注释",
DeletedID int(10) comment"注释",
Deletedate datetime comment"注释",
PRIMARY KEY(FInterID)
)ENGINE=Innodb default charset=utf8;'
);
 
PREPARE create_stmt FROM @csql;
EXECUTE create_stmt;
SET i = i+1;
END WHILE;
 
END;

